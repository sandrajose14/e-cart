import React from 'react'

function Wishlist() {
  return (
    <div>Wishlist</div>
  )
}

export default Wishlist