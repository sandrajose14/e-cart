import React from 'react'
import Container from 'react-bootstrap/Container';
import { Nav, Button } from 'react-bootstrap'
import Navbar from 'react-bootstrap/Navbar';

function Header() {
  return (
    <Navbar expand="lg" className="bg-warning px-5 py-2">
    <Container fluid>
      <Navbar.Brand href="#">Navbar scroll</Navbar.Brand>
      <Navbar.Toggle aria-controls="navbarScroll" />
      <Navbar.Collapse id="navbarScroll">
       <Nav className="ms-auto">
        <Button className='btn btn-outline-light rounded'>Wishlist</Button>
        <Button className='btn btn-outline-light rounded ms-5 me-5'>Cart</Button>

       </Nav>
      </Navbar.Collapse>
    </Container>
  </Navbar>
  )
}

export default Header